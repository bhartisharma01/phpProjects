
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Webartihc  </title>
		<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
		<!-- google font -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/ionicons.css" rel="stylesheet" type="text/css">
		<link href="css/simple-line-icons.css" rel="stylesheet" type="text/css">
<!--Morris Chart -->
		<link rel="stylesheet" href="css/morris.css">
		<link href="css/jquery.mCustomScrollbar.css" rel="stylesheet">
		<link href="css/weather-icons.min.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive.css" rel="stylesheet">
	</head>

<body style="background: #fff url(images/admin-login-background.png);background-attachment: fixed;background-repeat: repeat;" data-gr-c-s-loaded="true">
 	<div class="container">
 		<div class="row">
 			<div class="col-md-3"></div>

 			<div class="col-md-6 text-center">
 				<div class="admin-login-form">
 					<div class="admin-header-info">
 						<img src="images/logo.png" alt="" class="admin-logo">
 						<h3 class="admin-text">
 							Please Enter Your Information
 						</h3>
 					</div>

 					 <form action="" method="POST">
											<div class="form-group">
												
												<input type="email" class="form-control" id="emailid" aria-describedby="emailHelp" placeholder="Username">
												
											</div>
											<div class="form-group">
												
												<input type="password" class="form-control" id="password" placeholder="Password">
											</div>
											
											<div class="form-group"><input type="submit" class="btn btn-primary admin-login-btn form-control"></div>
										</form>


										   <div class="admin-login-copyrights">Designed &amp; Developed By : <a href="#" target="_blank">Bharti Sharma</a></div>
 				</div>
 			</div>

 			<div class="col-md-3"></div>

 		</div>
 	</div>

 

  
</body> 	
</html>