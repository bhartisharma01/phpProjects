<div class="side_bar scroll_auto">
					

					<ul id="dc_accordion" class="sidebar-menu tree">
						<li class="menu_sub active">
							<a href="dashboard.php"> <i class="fa fa-home"></i> <span>Dashboard</span>  </a>
							
						</li>

						<li class="menu_sub">
							<a href="#"> <i class="fa fa-newspaper-o"></i> <span> Category </span>  </a>
							
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-newspaper-o"></i> <span>Courses</span>  </a>
							
						</li>
						<!-- <li class="menu_sub">
							<a href="edit-vendor.php"> <i class="fa fa-newspaper-o"></i> <span>Edit Vendor</span>  </a>
							
						</li> -->
						
						
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-table"></i> <span>Learning Resources </span>  </a>
							
						</li>
						<li class="menu_sub">

						<a href="#"><i class="fa fa-table"></i> <span>Learning Resources Plan</span></a>
					</li>
									<li class="menu_sub">

						<a href="#"><i class="fa fa-table"></i> <span>Upload</span></a>
					</li>
									<li class="menu_sub">

						<a href="#"><i class="fa fa-table"></i> <span>Logout</span></a>
					</li>
						
						<!-- <li class="menu_sub dcjq-parent-li">
							<a href="#" class="dcjq-parent"> <i class="fa fa-table"></i> <span>Reports </span> <span class="arrow"></span> <span class="dcjq-icon"></span></a>
							<ul class="down_menu" style="display: none;">
								<li>
									<a href="#">Category Wise Deals</a>
								</li>
								<li>
									<a href="#">Location Wise Deals</a>
								</li>
							</ul>
						</li> -->
						
						
						
					</ul>
				</div>