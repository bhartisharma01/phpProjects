<?php include 'header.php';?>

			<!-- Content_right -->
			<div class="container_full">

				<?php include 'left-sidebar.php'; ?>

				<div class="content_wrapper">
					<div class="container-fluid">
						<!-- breadcrumb -->
						<div class="page-heading">
							<div class="row d-flex align-items-center">
								<div class="col-md-6">
									<div class="page-breadcrumb">
										<!-- <h1>Add Vendor</h1> -->
									</div>
								</div>
								<div class="col-md-6 justify-content-md-end d-md-flex">
									<div class="breadcrumb_nav">
										<ol class="breadcrumb">
											<li>
												<i class="fa fa-home"></i>
												<a class="parent-item" href="index.php">Home</a>
												<i class="fa fa-angle-right"></i>
											</li>
											<li class="active">
												Dashboard
											</li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<!-- breadcrumb_End -->
</div>

<div class="container-fluid">
						<!-- state start-->
	<div class="row">
		<div class=" col-xl-12">
			<div class="card card-shadow mb-4">
				<div class="card-header">
					<div class="card-title">
						Registered Students
					</div>
				</div>
				<div class="card-body">
					<table class="table table-bordered table-responsive" id="DashboardTable">
						<thead>
							<tr>
							<th>Student Id</th>
							<th>Registration Date</th>
							<th>Category</th>
							<th>Course</th>
							<th>Name</th>
							<th>Email</th>
							<th>Password</th>
							<th>Contact No.</th>
							<th>Gender</th>
							<th>Address</th>
							<th>Zip Code</th>
							<th>Status</th>
							
							<th>Edit</th>
							</tr>
						</thead>
						<tbody id="VendorTable">	
								<tr>
									<td>1</td>
									<td>10/06/20</td>
									<td>Automobiles</td>
									<td>ABC Cars</td>
									<td>Toronto, Canada</td>
									<td>8789878987</td>
									<td>10% off on all automobiles</td>
									<td><a href="#"><i class="fa fa-pencil"></i></a></td>
								</tr>
								<tr>
									<td>2</td>
									<td>11/06/20</td>
									<td>Grocery</td>
									<td>ABC Grocery Shop</td>
									<td>Ontario, Canada</td>
									<td>8789878987</td>
									<td>25% discount on all grocery items </td>
									<td><a href="#"><i class="fa fa-pencil"></i></a></td>
								</tr>	
								<tr>
									<td>3</td>
									<td>1/06/20</td>
									<td>Electronics</td>
									<td>ABC Electronics</td>
									<td>Vacouver,Canada</td>
									<td>8789878987</td>
									<td>Buy 2 and get power bank free</td>
									<td><a href="#"><i class="fa fa-pencil"></i></a></td>
								</tr>	
								<tr>
									<td>4</td>
									<td>19/06/20</td>
									<td>Automobiles</td>
									<td>XYZ Cars</td>
									<td>Toronto, Canada</td>
									<td>8789878987</td>
									<td>5% off on Cars</td>
									<td><a href="#"><i class="fa fa-pencil"></i></a></td>
								</tr>	
							

						</tbody>
					</table>				
				</div>
			</div>
		</div>
	</div>
						<!-- state end-->
</div>

	</div>
</div>
			<?php include 'footer.php';?>
		

