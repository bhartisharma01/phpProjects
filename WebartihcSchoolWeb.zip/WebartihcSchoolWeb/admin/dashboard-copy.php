
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Rundealz - Get your best deal </title>
		<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
		<!-- google font -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/ionicons.css" rel="stylesheet" type="text/css">
		<link href="css/simple-line-icons.css" rel="stylesheet" type="text/css">
<!--Morris Chart -->
		<link rel="stylesheet" href="css/morris.css">
		<link href="css/jquery.mCustomScrollbar.css" rel="stylesheet">
		<link href="css/weather-icons.min.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive.css" rel="stylesheet">
	</head>

	<body>
		<div class="wrapper">
			<!-- header -->
			<header class="main-header">
				<div class="container_header">
					<div class="logo d-flex align-items-center">
						<a href="#"> <strong class="logo_icon"> <img src="images/small-logo.png" alt=""> </strong> 
							<span class="logo-default"> <img src="images/logo.png" alt=""> </span> </a>
						<div class="icon_menu full_menu">
							<a href="#" class="menu-toggler sidebar-toggler"></a>
						</div>
					</div>
					<div class="right_detail">
						<div class="row d-flex align-items-center min-h pos-md-r">
							<div class="col-xl-5 col-3 search_col ">
								<div class="top_function">

									<div class="search">
										<a id="toggle_res_search" data-toggle="collapse" data-target="#search_form" class="res-only-view collapsed" href="javascript:void(0);"
										aria-expanded="false"> <i class=" icon-magnifier"></i> </a>
										<form id="search_form" role="search" class="search-form collapse" action="#">
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search...">
												<button type="button" class="btn" data-target="#search_form" data-toggle="collapse" aria-label="Close">
													<i class="ion-android-search"></i>
												</button>
											</div>
										</form>
									</div>
								</div>
							</div>
							<div class="col-xl-7 col-9 d-flex justify-content-end">
								<div class="right_bar_top d-flex align-items-center">

									<!-- notification_Start -->
									<div class="dropdown dropdown-notification">
										<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="false"> <i class="fa fa-bell-o"></i> <span class="badge_coun"> 6 </span> </a>
										<ul class="dropdown-menu scroll_auto height_fixed">
											<li class="bigger">
												<h3><span class="bold">Notifications</span></h3>
												<span class="notification-label">New 6</span>
											</li>
											<li>
												<ul class="dropdown-menu-list">
													<li>
														<a href="javascript:;"> <span class="time">just now</span> <span class="details"> <span class="notification-icon deepPink-bgcolor"> <i class="fa fa-check"></i> </span> Congratulations!. </span> </a>
													</li>
													<li>
														<a href="javascript:;"> <span class="time">3 mins</span> <span class="details"> <span class="notification-icon purple-bgcolor"> <i class="fa fa-user o"></i> </span> <b>John Micle </b>is now following you. </span> </a>
													</li>
													<li>
														<a href="javascript:;"> <span class="time">7 mins</span> <span class="details"> <span class="notification-icon blue-bgcolor"> <i class="fa fa-comments-o"></i> </span> <b>Sneha Jogi </b>sent you a message. </span> </a>
													</li>
													<li>
														<a href="javascript:;"> <span class="time">12 mins</span> <span class="details"> <span class="notification-icon pink"> <i class="fa fa-heart"></i> </span> <b>Ravi Patel </b>like your photo. </span> </a>
													</li>
													<li>
														<a href="javascript:;"> <span class="time">15 mins</span> <span class="details"> <span class="notification-icon yellow"> <i class="fa fa-warning"></i> </span> Warning! </span> </a>
													</li>
													<li>
														<a href="javascript:;"> <span class="time">10 hrs</span> <span class="details"> <span class="notification-icon red"> <i class="fa fa-times"></i> </span> Application error. </span> </a>
													</li>
												</ul>
											</li>
										</ul>
									</div>
									<!-- notification_End -->
									<!-- DropDown_Inbox -->
									<div class="dropdown dropdown-inbox">
										<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> <i class="fa fa-envelope-o"></i> <span class="badge_coun"> 2 </span> </a>
										<ul class="dropdown-menu scroll_auto height_fixed">
											<li class="bigger">
												<h3><span class="bold">Messages</span></h3>
												<span class="notification-label">New 2</span>
											</li>
											<li>
												<ul class="dropdown-menu-list">
													<li>
														<a href="#"> <span class="photo"> <img src="images/about-1.jpg" class="img-circle" alt=""> </span> <span class="subject"> <span class="from"> Sarah Smith </span> <span class="time">Just Now </span> </span> <span class="message"> Jatin I found you on LinkedIn... </span> </a>
													</li>
													<li>
														<a href="#"> <span class="photo"> <img src="images/about-1.jpg" class="img-circle" alt=""> </span> <span class="subject"> <span class="from"> Sarah Smith </span> <span class="time">Just Now </span> </span> <span class="message"> Jatin I found you on LinkedIn... </span> </a>
													</li>
													<li>
														<a href="#"> <span class="photo"> <img src="images/about-1.jpg" class="img-circle" alt=""> </span> <span class="subject"> <span class="from"> Sarah Smith </span> <span class="time">Just Now </span> </span> <span class="message"> Jatin I found you on LinkedIn... </span> </a>
													</li>
													<li>
														<a href="#"> <span class="photo"> <img src="images/about-1.jpg" class="img-circle" alt=""> </span> <span class="subject"> <span class="from"> Sarah Smith </span> <span class="time">Just Now </span> </span> <span class="message"> Jatin I found you on LinkedIn... </span> </a>
													</li>
													<li>
														<a href="#"> <span class="photo"> <img src="images/about-1.jpg" class="img-circle" alt=""> </span> <span class="subject"> <span class="from"> Sarah Smith </span> <span class="time">Just Now </span> </span> <span class="message"> Jatin I found you on LinkedIn... </span> </a>
													</li>
													<li>
														<a href="#"> <span class="photo"> <img src="images/about-1.jpg" class="img-circle" alt=""> </span> <span class="subject"> <span class="from"> Sarah Smith </span> <span class="time">Just Now </span> </span> <span class="message"> Jatin I found you on LinkedIn... </span> </a>
													</li>
												</ul>
											</li>
										</ul>
									</div>
									<!--DropDown_Inbox_End -->
									<!-- Dropdown_User -->
									<div class="dropdown dropdown-user">
										<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="true"> <img class="img-circle pro_pic" src="images/about-1.jpg" alt=""> </a>
										<ul class="dropdown-menu dropdown-menu-default">
											<li>
												<a href="#"> <i class="icon-user"></i> Profile </a>
											</li>
											<li>
												<a href="#"> <i class="icon-settings"></i> Settings </a>
											</li>
											<li>
												<a href="#"> <i class="icon-directions"></i> Help </a>
											</li>
											<li class="divider"></li>
											<li>
												<a href="lock_screen.html"> <i class="icon-lock"></i> Lock </a>
											</li>
											<li>
												<a href="#"> <i class="icon-logout"></i> Log Out </a>
											</li>
										</ul>
									</div>
									<!-- Dropdown_User_End -->
								</div>
							</div>
						</div>
					</div>
				</div>

			</header>
			<!-- header_End -->
			<!-- Content_right -->
			<div class="container_full">

				<div class="side_bar scroll_auto">
					<div class="user-panel">
						<div class="user_image">
							<img src="images/about-1.jpg" class="box_all_shedo img-circle mCS_img_loaded" alt="User Image">
						</div>
						<div class="info">
							<p>
								Peter Siddle
							</p>
							<a href="#"> <i class="fa fa-circle text-success"></i> Online</a>
						</div>
					</div>

					<ul id="dc_accordion" class="sidebar-menu tree">
						<li class="menu_sub active">
							<a href="#"> <i class="fa fa-home"></i> <span>Dashboard</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="index.html">Dashboard 1</a>
								</li>								
							</ul>
						</li>

						<li class="menu_sub">
							<a href="#"> <i class="fa fa-newspaper-o"></i> <span>UI Elements </span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="dropdown.html">Dropdowns</a>
								</li>
								<li>
									<a href="buttons.html">Buttons</a>
								</li>
								<li>
									<a href="lists.html">Lists</a>
								</li>
								<li>
									<a href="alert.html">Alerts</a>
								</li>
								<li>
									<a href="modal.html">Modals</a>
								</li>
								<li>
									<a href="cards.html">Cards</a>
								</li>
								<li>
									<a href="progress.html"> Progress</a>
								</li>
								<li>
									<a href="grid.html">Grids</a>
								</li>
								<li>
									<a href="typography.html">Typography</a>
								</li>
								<li>
									<a href="popover-tooltips.html">Popover &amp; Tooltips</a>
								</li>
								<li>
									<a href="tabs.html">Tabs</a>
								</li>
								<li>
									<a href="tree.html">Tree</a>
								</li>
								<li>
									<a href="toastr.html">Toastr Notification</a>
								</li>
							</ul>
						</li>
						
						
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-table"></i> <span>Widgets </span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="widgets-base.html">Widgets Base</a>
								</li>
								<li>
									<a href="widgets-chart.html">Widgets Chart</a>
								</li>
							</ul>
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-pie-chart"></i> <span>Portlets</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="portlet-base.html">Portlets Base</a>
								</li>
								<li>
									<a href="portlet-advanced.html">Portlets Advanced</a>
								</li>
							</ul>
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-calendar"></i> <span>Calendar </span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="calendar-basic.html">Basic Calendar</a>
								</li>
								<li>
									<a href="calendar-external-events.html">External Events Calendar</a>
								</li>
								<li>
									<a href="calendar-list.html">List Calendar</a>
								</li>
							</ul>
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="icon-grid"></i> <span>Data Tables</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="table-basic.html">Basic Table</a>
								</li>
								<li class="menu_sub">
									<a href="#">Data Tables <span class="arrow"></span> </a>
									<ul class="down_menu">
										<li>
											<a href="table-datatable.html">Basic Datatable</a>
										</li>
										<li>
											<a href="table-datatable-show-hide.html">Toggle Col Datatable</a>
										</li>
										<li>
											<a href="table-datatable-ajax.html">Ajax Datatable</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-laptop"></i> <span>Icons</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="icon-font-awesome.html">Fontawesome Icons</a>
								</li>
								<li>
									<a href="icon-simple-line.html">Simple line Icons</a>
								</li>
							</ul>
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-wpforms"></i> <span>Forms</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li class="menu_sub">
									<a href="#">Form Control <span class="arrow"></span> </a>
									<ul class="down_menu lavel3">
										<li>
											<a href="form-basic-input.html">Basic Input</a>
										</li>
										<li>
											<a href="form-input-group.html">Input Group</a>
										</li>
										<li>
											<a href="form-checkbox-radio.html">Checkbox & Radio</a>
										</li>
									</ul>
								</li>
								<li class="menu_sub">
									<a href="#">Form Validation <span class="arrow"></span> </a>
									<ul class="down_menu lavel3">
										<li>
											<a href="form-validation-basic.html">Basic Validation</a>
										</li>
										<li>
											<a href="form-validation-jquery.html">jQuery Validation</a>
										</li>
										<li>
											<a href="form-wizard.html">Form Wizard</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-bar-chart text-aqua"></i> <span>Charts</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="flot-chart.html">Flot Charts</a>
								</li>
								<li>
									<a href="echart.html">eCharts</a>
								</li>
								
							</ul>
						</li>
						<li class="menu_sub">
							<a href="#"> <i class="fa fa-file text-aqua"></i> <span>Extra Pages</span> <span class="arrow"></span> </a>
							<ul class="down_menu">
								<li>
									<a href="profile.html">User Profile</a>
								</li>
								<li>
									<a href="page-login.html">Sign In</a>
								</li>
								<li>
									<a href="page-register.html">Sign Up</a>
								</li>
								<li>
									<a href="invoice.html">Invoice</a>
								</li>
								<li>
									<a href="page_404.html">404</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>

				<div class="content_wrapper">
					<div class="container-fluid">
						<!-- breadcrumb -->
						<div class="page-heading">
							<div class="row d-flex align-items-center">
								<div class="col-md-6">
									<div class="page-breadcrumb">
										<h1>Dashboard</h1>
									</div>
								</div>
								<div class="col-md-6 justify-content-md-end d-md-flex">
									<div class="breadcrumb_nav">
										<ol class="breadcrumb">
											<li>
												<i class="fa fa-home"></i>
												<a class="parent-item" href="index.html">Home</a>
												<i class="fa fa-angle-right"></i>
											</li>
											<li class="active">
												Dashboard
											</li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<!-- breadcrumb_End -->

						<!-- Section -->
						<section class="chart_section">

							<div class="row">
								
								<div class="col-xl-3 col-md-6 mb-4">							
							<div class="card bg_gradient1">
								<div class="card-body">
									<div class="row">
										<div class="col-12">
											<div class="float-right">
												<span class="card-subtitle text-light fw_500">248</span>
												<p class="card-subtitle text-light fw_500">per week</p>
											</div>
											<h3 class="text-light">Traffic</h3>
											<p class="card-subtitle text-light fw_500">
												 36% Increase
											</p>
										</div>
										<div class="col-12">
											<div class="progress mt-3 mb-1 h-6">
												<div class="progress-bar bg-dark-blue" role="progressbar" aria-valuenow="63" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
											<div class="text-light f12">
												<span>Progress</span>
												<span class="float-right text-light">83%</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>
							<!-- Column -->
							
							<!-- Column -->
							<div class="col-xl-3 col-md-6 mb-4">
							<div class="card bg_gradient2">
								<div class="card-body">
									<div class="row">
										<div class="col-12">
											<div class="float-right">
												<span class="card-subtitle text-light fw_500">16%</span>
												<p class="card-subtitle text-light fw_500">profit earn</p>
											</div>
											<h3 class="text-light">Sales</h3>
											<p class="card-subtitle text-light fw_500">
												19% Increase
											</p>
										</div>
										<div class="col-12">
											<div class="progress mt-3 mb-1 h-6">
												<div class="progress-bar bg-light-green" role="progressbar" aria-valuenow="63" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
											<div class="text-light f12">
												<span>Progress</span>
												<span class="float-right">63%</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>
							<!-- Column -->
							
							<!-- Column -->
							<div class="col-xl-3 col-md-6 mb-4">
							<div class="card bg_gradient3">
								<div class="card-body">
									<div class="row">
										<div class="col-12">
											<div class="float-right">
												<span class="card-subtitle text-light fw_500">29</span>
												<p class="card-subtitle text-light fw_500">of 456</p>
											</div>
											<h3 class="text-light">New Client</h3>
											<p class="card-subtitle text-light fw_500">
												25% more
											</p>
										</div>
										<div class="col-12">
											<div class="progress mt-3 mb-1 h-6">
												<div class="progress-bar bg-dark-red" role="progressbar" aria-valuenow="77" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
											<div class="text-light f12">
												<span>Progress</span>
												<span class="float-right">77%</span>
											</div>
										</div>
									</div>

								</div>
							</div>
							</div>
							<!-- Column -->
						
							<!-- Column -->
							<div class="col-xl-3 col-md-6 mb-4">
							<div class="card bg_gradient4">
								<div class="card-body">
									<div class="row">
										<div class="col-12">
											<div class="float-right">
												<span class="card-subtitle text-light fw_500">139</span>
												<p class="card-subtitle text-light fw_500">of 6753</p>
											</div>
											<h3 class="text-light">Online</h3>
											<p class="card-subtitle text-light fw_500">
												Online Users
											</p>
										</div>
										<div class="col-12">
											<div class="progress mt-3 mb-1 h-6">
												<div class="progress-bar bg-light-yellow" role="progressbar"  aria-valuenow="56" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
											<div class="text-light f12">
												<span>Progress</span>
												<span class="float-right">56%</span>
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>
						
								
							</div>

							<div class="row">
								<div class="col-md-12">
									<div class="card card-shadow mb-4">
									<div class="card-header">
										<div class="card-title">
											Traffic Views
										</div>
									</div>
									<div class="card-body">
										<div id="area-chart"></div>
									</div>
								</div>

								</div>
							</div>
						
						<div class="row">
							
							<div class="col-xl-4 col-lg-6">
								<div class="card card-shadow mb-4">
									<div class="card-header">
										<div class="card-title">
											Recent Activities											
										</div>
									</div>
									<div class="card-body">
										<div class="baseline home_space baseline-border">
											<div class="baseline-list">
												<div class="baseline-info">
													<div>
														<a href="#" class="default-color"> <strong>John Tasi</strong> </a> Prepare for the Meeting <span class="badge badge-pill badge-success">status</span>
													</div>
													<span class="text-muted">10:00 PM Sat, 10 Jan 2018</span>
												</div>
											</div>
											<div class="baseline-list baseline-border baseline-primary">
												<div class="baseline-info">
													<div>
														Video conference to client
													</div>
													<span class="text-muted">05:00 PM Sun, 02 Feb 2018</span>
												</div>
											</div>
											<div class="baseline-list  baseline-border baseline-success">
												<div class="baseline-info">
													<div>
														<a href="#" class="default-color"> <strong>Tnisha</strong> </a> Submit a blog post <a href="#" class="">best admin template in 2018.</a>
													</div>
													<span class="text-muted">10:00 PM Sat, 10 Jan 2018</span>
												</div>
											</div>
											<div class="baseline-list  baseline-border baseline-warning">
												<div class="baseline-info">
													<div>
														<a href="#" class="default-color"> <strong>New Request</strong> </a> 10 user request to approve or remove
													</div>
													<span class="text-muted">10:00 PM Sat, 10 Jan 2018</span>
												</div>
											</div>
											<div class="baseline-list  baseline-border baseline-info">
												<div class="baseline-info">
													<div>
														<a href="#" class="default-color"> <strong>Mark Henry</strong> </a> added your friend list now
													</div>
													<span class="text-muted">10:00 PM Sat, 10 Jan 2018</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						
							<div class="col-xl-8 col-lg-6">
							<div class="card card-shadow mb-4">
									<div class="card-header">
										<div class="card-title">
											Combine Statistics
										</div>
									</div>
									<div class="card-body">
										<div id="combine-chart">
											<div id="combine-chart-container"></div>
										</div>
									</div>
								</div>

						</div>
						
						</div>
						
						<div class="row">
							
							<div class="col-lg-12 col-xl-4">
								<div class="card card-shadow mb-4">
									<div class="card-header">
										<div class="card-title">
											New Users											
										</div>
									</div>
									<div class="card-body">
										
										<div class="media mb-4">
											<img class="align-self-center mr-3 rounded-circle w_50" src="images/user2.png" alt=" ">
											<div class="media-body">
												<p class="mb-0">
													<strong class="">Tnisha Sabrin</strong>
												</p>
												<span>tnisha_s@testmail.com</span>
											</div>
											<div class="btn-group float-right task-list-action">
												<div class="dropdown ">
													<a href="#" class="btn btn-transparent gray-color dropdown-hover p-0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class=" icon-options"></i> </a>
													<div class="dropdown-menu dropdown-menu-right ">
														<a class="dropdown-item" href="#"> <i class="icon-user text-info pr-2"></i> Follow</a>
														<a class="dropdown-item" href="#"> <i class=" icon-user-unfollow text-danger pr-2"></i> Un Follow</a>
													</div>
												</div>
											</div>
										</div>
										<div class="media mb-4">
											<img class="align-self-center mr-3 rounded-circle w_50" src="images/user3.png" alt=" " >
											<div class="media-body">
												<p class="mb-0">
													<strong class="">Tasi Szzd</strong>
												</p>
												<span>tasi_szd@testmail.com</span>
											</div>
											<div class="btn-group float-right task-list-action">
												<div class="dropdown ">
													<a href="#" class="btn btn-transparent gray-color dropdown-hover p-0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class=" icon-options"></i> </a>
													<div class="dropdown-menu dropdown-menu-right ">
														<a class="dropdown-item" href="#"> <i class="icon-user text-info pr-2"></i> Follow</a>
														<a class="dropdown-item" href="#"> <i class=" icon-user-unfollow text-danger pr-2"></i> Un Follow</a>
													</div>
												</div>
											</div>
										</div>
										<div class="media mb-4">
											<img class="align-self-center mr-3 rounded-circle w_50" src="images/user4.png" alt=" " >
											<div class="media-body">
												<p class="mb-0">
													<strong class="">Keny Rose</strong>
												</p>
												<span>keny_ose@testmail.com</span>
											</div>
											<div class="btn-group float-right task-list-action">
												<div class="dropdown ">
													<a href="#" class="btn btn-transparent gray-color dropdown-hover p-0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class=" icon-options"></i> </a>
													<div class="dropdown-menu dropdown-menu-right ">
														<a class="dropdown-item" href="#"> <i class="icon-user text-info pr-2"></i> Follow</a>
														<a class="dropdown-item" href="#"> <i class=" icon-user-unfollow text-danger pr-2"></i> Un Follow</a>
													</div>
												</div>
											</div>
										</div>
										<div class="media mb-4">
											<img class="align-self-center mr-3 rounded-circle w_50" src="images/user5.png" alt=" " >
											<div class="media-body">
												<p class="mb-0">
													<strong class="">MH Geek</strong>
												</p>
												<span>mh_g@testmail.com</span>
											</div>
											<div class="btn-group float-right task-list-action">
												<div class="dropdown ">
													<a href="#" class="btn btn-transparent gray-color dropdown-hover p-0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class=" icon-options"></i> </a>
													<div class="dropdown-menu dropdown-menu-right ">
														<a class="dropdown-item" href="#"> <i class="icon-user text-info pr-2"></i> Follow</a>
														<a class="dropdown-item" href="#"> <i class=" icon-user-unfollow text-danger pr-2"></i> Un Follow</a>
													</div>
												</div>
											</div>
										</div>
										<div class="media ">
											<img class="align-self-center mr-3 rounded-circle w_50" src="images/user2.png" alt=" " >
											<div class="media-body">
												<p class="mb-0">
													<strong class="">Tnisha Sabrin</strong>
												</p>
												<span>tnisha_s@testmail.com</span>
											</div>
											<div class="btn-group float-right task-list-action">
												<div class="dropdown ">
													<a href="#" class="btn btn-transparent gray-color dropdown-hover p-0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class=" icon-options"></i> </a>
													<div class="dropdown-menu dropdown-menu-right ">
														<a class="dropdown-item" href="#"> <i class="icon-user text-info pr-2"></i> Follow</a>
														<a class="dropdown-item" href="#"> <i class=" icon-user-unfollow text-danger pr-2"></i> Un Follow</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						
						<div class="col-lg-6 col-xl-4">
							<div class="full_chart card-shadow border-0 card mb-4">
									<div class="card-header">
										<div class="card-title">
											Resent Chat
										</div>
									</div>
									<div class="card_chart">
										<div class="chat_box scroll_auto">
											<div class="left_align_me">
												<img src="images/img1.jpg" alt="" class="rounded-circle" />
												<div class="chat-info">       
                                            <span class="message">Hello, John<br>What is the update on Project?</span>
                                        </div>
											</div>
											
											<div class="right_align_me">
												<img src="images/img2.jpg" alt="" class="rounded-circle" />
												<div class="chat-info">       
                                            <span class="message">Hello, John<br>What is the update on Project?</span>
                                        </div>
											</div>
											
											<div class="left_align_me">
												<img src="images/img1.jpg" alt="" class="rounded-circle" />
												<div class="chat-info">       
                                            <span class="message">Hello, John<br>What is the update on Project?</span>
                                        </div>
											</div>
											
											<div class="right_align_me">
												<img src="images/img2.jpg" alt="" class="rounded-circle" />
												<div class="chat-info">       
                                            <span class="message">Hello, John<br>What is the update on Project?</span>
                                        </div>
											</div>
											
											<div class="left_align_me">
												<img src="images/img1.jpg" alt="" class="rounded-circle" />
												<div class="chat-info">       
                                            <span class="message">Hello, John<br>What is the update on Project?</span>
                                        </div>
											</div>
											
											<div class="right_align_me">
												<img src="images/img2.jpg" alt="" class="rounded-circle" />
												<div class="chat-info">       
                                            <span class="message">Hello, John<br>What is the update on Project?</span>
                                        </div>
											</div>
											
										</div>
										
										<div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="icon-paper-plane"></i></span>
                                </div>
                                <input type="text" class="form-control" placeholder="Enter text here...">                                    
                            </div>
									</div>
								</div>
						</div>
						
						<div class="col-lg-6 col-xl-4">
								<div class="card card-shadow mb-4">
									<div class="card-header">
										<div class="card-title">
											Task Progress										
										</div>
									</div>
									<div class="card-body">
										<div id="sparkline_2" class="text-center bor_space"></div>
												<div class="task_box">
													<div class="task_num text-muted border-right f16">
														 Urgent Tasks
														 <h1 class="text-primary f45">08 <span class="f16 fw_500 text-muted">Tasks</span></h1>
													</div>
													<div class="task_num f16 text-muted">
														 Normal Tasks
														 <h1 class="text-primary f45">05 <span class="f16 fw_500 text-muted">Tasks</span></h1>
													</div>
												</div>
												
												 <div class="task-assign f16 text-center">
                                    Assigned To
                                    <ul class="list-inline">
                                        <li class="pl-0">
                                            <img src="images/img1.jpg" alt="user" data-toggle="tooltip" data-placement="top" title="" class="img-circle" data-original-title="Jon Holland">
                                        </li>
                                        <li>
                                            <img src="images/img2.jpg" alt="user" data-toggle="tooltip" data-placement="top" title="" class="img-circle" data-original-title="Jon Holland">
                                        </li>
                                        <li>
                                            <img src="images/img3.jpg" alt="user" data-toggle="tooltip" data-placement="top" title="" class="img-circle" data-original-title="Jon Holland">
                                        </li>
                                        <li class="pr-0">
                                            <a href="javascript:void(0);" class="btn rounded-circle btn-success f16">3+</a>
                                        </li>
                                    </ul>
                                </div>

									</div>
								</div>
							</div>
												
						</div>
						
						<div class="row">
							
							<div class="col-lg-12 col-xl-6">
									<div class="card card-shadow mb-4">
										<div class="card-header">
											<div class="card-title">
												Product Reports
												
											</div>
										</div>
										<div class="table-responsive">
											<table class="table table-vertical-middle">
												<thead>
													<tr>
														<th class="border-0 ">Product Thumb</th>
														<th class="border-0">Product Info</th>
														<th class="border-0 text-right">Total Sold</th>
														<th class="border-0 text-right">Rating</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td	><img src="images/product_img.jpg" alt="" width="100"></td>
														<td><h6 class="mb-0">15" Mackbook Pro <br> Retina Display</h6><span class="f12">Category: Computer Electronics</span>
														<div class="text-muted">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-half-empty"></i>
														</div></td>
														<td  class="text-right"><h4 class="text-muted">2345</h4></td>
														<td class="text-right"><h4 class="text-muted">123</h4></td>
													</tr>
													<tr>
														<td><img src="images/product_2.jpg" alt="" width="100"></td>
														<td><h6 class="mb-0">27" iMac Por <br>Latest versin</h6><span class="f12">Category: Computer Electronics</span>
														<div class="text-muted">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-half-empty"></i>
															<i class="fa fa-star-o"></i>
														</div></td>
														<td class="text-right"><h4 class="text-muted">4321</h4></td>
														<td class="text-right"><h4 class="text-muted">432</h4></td>
													</tr>
													<tr>
														<td><img src="images/product_3.jpg" alt="" width="100"></td>
														<td><h6 class="mb-0">iPhone X</h6><span class="f12">Category: Mobile</span>
														<div class="text-muted">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
														</div></td>
														<td class="text-right"><h4 class="text-muted">5442</h4></td>
														<td class="text-right"><h4 class="text-muted">788</h4></td>
													</tr>

												</tbody>
											</table>
										</div>
									</div>
								</div>

						<div class="col-lg-12 col-xl-6 d-flex">
								<div class="card card-shadow mb-4">
									<div class="card-header">
										<div class="card-title">
											Browser Usage
										</div>
									</div>
									<div class="card-body">
										<div id="doughnut"></div>
									</div>
								</div>
							</div>

						
						</div>
						
						
						<div class="row">
							<div class="col-lg-3 col-md-6">
								<div class="social-box facebook mb-4">
									<i class="fa fa-facebook"></i>
									<ul>
										<li>
											<strong>
												<span class="count">40</span> k</strong>
											<span>friends</span>
										</li>
										<li>
											<strong>
												<span class="count">450</span>
											</strong>
											<span>feeds</span>
										</li>
									</ul>
								</div>
								<!--/social-box-->
							</div>
							<div class="col-lg-3 col-md-6">
								<div class="social-box twitter mb-4">
									<i class="fa fa-twitter"></i>
									<ul>
										<li>
											<strong>
												<span class="count">30</span> k</strong>
											<span>friends</span>
										</li>
										<li>
											<strong>
												<span class="count">450</span>
											</strong>
											<span>tweets</span>
										</li>
									</ul>
								</div>
								<!--/social-box-->
							</div>
							<div class="col-lg-3 col-md-6">
								<div class="social-box linkedin mb-4">
									<i class="fa fa-linkedin"></i>
									<ul>
										<li>
											<strong>
												<span class="count">40</span> +</strong>
											<span>contacts</span>
										</li>
										<li>
											<strong>
												<span class="count">250</span>
											</strong>
											<span>feeds</span>
										</li>
									</ul>
								</div>
								<!--/social-box-->
							</div>
							<div class="col-lg-3 col-md-6">
								<div class="social-box google-plus mb-4">
									<i class="fa fa-google-plus"></i>
									<ul>
										<li>
											<strong>
												<span class="count">94</span> k</strong>
											<span>followers</span>
										</li>
										<li>
											<strong>
												<span class="count">92</span>
											</strong>
											<span>circles</span>
										</li>
									</ul>
								</div>
								<!--/social-box-->
							</div>
						</div>
						
						
						</section>
						<!-- Section_End -->

					</div>
				</div>
			</div>
			<!-- Content_right_End -->
			<!-- Footer -->
			<footer class="footer ptb-20">
				<div class="row">
					<div class="col-md-12 text-center">
						<div class="copy_right">
							<p>
								2018 © Dashboard Theme By
								<a href="#">Metrian</a>
							</p>
						</div>
						<a id="back-to-top" href="#"> <i class="ion-android-arrow-up"></i> </a>
					</div>
				</div>
			</footer>
			<!-- Footer_End -->
		</div>
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/popper.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<!--Morris Chart-->
		<script src="js/morris.js"></script>
		<script src="js/raphael-min.js"></script>
		<!--morris chart initialization-->
		<script src="js/morris-init.js"></script>


	<!--flot chart -->
		<script src="js/jquery.flot.js"></script>
		<script src="js/jquery.flot.tooltip.min.js"></script>
		<script src="js/jquery.flot.resize.js"></script>
		<script src="js/jquery.flot.pie.js"></script>
		<script src="js/jquery.flot.stack.js"></script>
		<script src="js/jquery.flot.crosshair.js"></script>
		<script src="js/jquery.flot.time.js"></script>
		<!--flot initialization-->
		<script src="js/flot-chart-init.js"></script>
<!--sparkline chart-->
		<script src="js/jquery.sparkline.js"></script>
		<script src="js/sparkline-init.js"></script>
<!--echarts-->
		<script type="text/javascript" src="js/echarts-all-3.js"></script>
		<!--init echarts-->
		<script type="text/javascript" src="js/init-echarts.js"></script>



		<script type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
		<script src="js/custom.js" type="text/javascript"></script>


	</body>

</html>