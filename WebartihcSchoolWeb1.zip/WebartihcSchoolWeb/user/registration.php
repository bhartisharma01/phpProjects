<?php
include 'header.php';
?>

<body style="background: #fff url(images/admin-login-background.png);background-attachment: fixed;background-repeat: repeat;" data-gr-c-s-loaded="true">
 	<div class="container">
 		<div class="row">
 			<!-- <div class="col-md-1"></div> -->

 			<div class="col-md-12 text-center">
 				<div class="user-register-form">
 					<div class="admin-header-info">
 						<img src="images/logo.png" alt="" class="admin-logo">
 						<h3 class="admin-text">
 							Please Enter Your Information
 						</h3>
 					</div>

 					<form action="" method="POST">
						<div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
							        <input type="text" class="form-control" id="studentId"  placeholder="Student Id" name="studentId" autocomplete="off">
						        </div>
                            </div>    
                            <div class="col-md-4">
                                <div class="form-group">
							        <input type="text" class="form-control" id="rollNumber"  placeholder="Roll No." name="rollNumber" autocomplete="off">
						        </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
							        <input type="text" class="form-control" id="yourName" placeholder="Name" name="yourName" autocomplete="off">
						        </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
							        <input type="text" class="form-control" id="schoolName"  placeholder="School Name" name="schoolName" autocomplete="off" required>
						        </div>
                            </div>    
                            <div class="col-md-4">
                                <div class="form-group">
							        <select name="Class" id="class" class="form-control" required>
							        	<option value="">Select Class</option>
							        	<option value="">6</option>
							        	<option value="">7</option>
							        	<option value="">8</option>
							        	<option value="">9</option>
							        	<option value="">10</option>
							        </select>
						        </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
							        <select name="Section" id="section" class="form-control" required>
							        	<option value="">Select Section</option>
							        	<option value="">A</option>
							        	<option value="">B</option>
							        	<option value="">C</option>
							        	<option value="">D</option>
							        	<option value="">E</option>
							        </select>
						        </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
							        <select name="Medium" id="medium" class="form-control" required>
							        	<option value="">Medium </option>
							        	<option value="">English</option>
							        	<option value="">Hindi</option>
							        	
							        </select>
						        </div>
                            </div>    
                            <div class="col-md-4">
                                <div class="form-group">
							        <div class="form-group">
							        	<select name="Gender" id="gender" class="form-control" required>
							        	<option value="">Gender </option>
							        	<option value="">Male</option>
							        	<option value="">Female</option>
							        	
							        </select>
						        	</div>
						        </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
							        <div class="form-group">
							        	<input type="date" class="form-control" name="DateofBirth" placeholder="Date of Birth" required>
						        	</div>

						        </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
							        <input type="text" class="form-control" id="Address"  placeholder="Address" name="Address" autocomplete="off" required>
						        </div>
                            </div>    
                            <div class="col-md-4">
                                <div class="form-group">
							        <input type="password" class="form-control" id="password" placeholder="Password" name="Password" autocomplete="off" required>
						        </div>
                            </div>
                            
                            
                        </div>

                        <div class="row">
                            <div class="col-md-4">
						<div class="form-group">
							<input type="submit" class="btn btn-primary admin-login-btn form-control">
						</div>
					</div>
					<div class="col-md-4">
						
					</div>
					<div class="col-md-4"></div>
				</div>
					</form>
					<div class="row">
						<div class="col-md-12">
							<div class="admin-login-copyrights">Designed &amp; Developed By : <a href="#" target="_blank">Webartihc Technologies</a></div>
						</div>
					</div>
 					</div>
 				</div>
				 <!-- <div class="col-md-1"></div> -->
			</div>
 		</div>
<?php
include 'footer.php';
?>