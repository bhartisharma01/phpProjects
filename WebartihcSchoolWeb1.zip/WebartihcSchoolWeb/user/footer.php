<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/popper.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<!--Morris Chart-->
		<script src="js/morris.js"></script>
		<script src="js/raphael-min.js"></script>
		<!--morris chart initialization-->
		<script src="js/morris-init.js"></script>


	<!--flot chart -->
		<script src="js/jquery.flot.js"></script>
		<script src="js/jquery.flot.tooltip.min.js"></script>
		<script src="js/jquery.flot.resize.js"></script>
		<script src="js/jquery.flot.pie.js"></script>
		<script src="js/jquery.flot.stack.js"></script>
		<script src="js/jquery.flot.crosshair.js"></script>
		<script src="js/jquery.flot.time.js"></script>
		<!--flot initialization-->
		<script src="js/flot-chart-init.js"></script>
<!--sparkline chart-->
		<script src="js/jquery.sparkline.js"></script>
		<script src="js/sparkline-init.js"></script>
<!--echarts-->
		<script type="text/javascript" src="js/echarts-all-3.js"></script>
		<!--init echarts-->
		<script type="text/javascript" src="js/init-echarts.js"></script>


<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
		<script type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
		<script src="js/custom.js" type="text/javascript"></script>
		
		<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>

 <script>
  $(function(){
    $("#DashboardTable").dataTable();
  })
  </script>
			
	</body>

</html>