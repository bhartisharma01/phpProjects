<div class="side_bar scroll_auto">
					

					<ul id="dc_accordion" class="sidebar-menu tree">
						<li class="menu_sub active">
							<a href="Profile.php"> <i class="fa fa-home"></i> <span>My Learning Dashboard</span>  </a>
							
						</li>

						<li class="menu_sub">
							<a> <i class="fa fa-newspaper-o"></i> <span> class 7B - Englsih Medium </span>  </a>
							
						</li>
						<li class="menu_sub ">
							<a href="Profile.php"> <i class="fa fa-newspaper-o"></i>  <span>My Profile</span>  </a>
							
						</li>
						<li class="menu_sub">
							<a href="Announcements.php"> <i class="fa fa-newspaper-o"></i> <span>Announcements</span>  </a>
							
						</li>
						
						<li class="menu_sub dcjq-parent-li">
							<a href="#" class="dcjq-parent"> <i class="fa fa-table"></i> <span>Subject Notes </span> <span class="arrow"></span> <span class="dcjq-icon"></span></a>
							<ul class="down_menu" >
								<li>
									<a href="Hindi.php">Hindi</a>
								</li>
								<li>
									<a href="English.php">English</a>
								</li>
								<li>
									<a href="Matematics.php">Mathematics</a>
								</li>
								<li>
									<a href="Science.php">Science</a>
								</li>
								<li>
									<a href="SocialScience.php">Social Science</a>
								</li>
								<li>
									<a href="Sanskrit.php">Sanskrit</a>
								</li>
							</ul>
						</li>
						<li class="menu_sub dcjq-parent-li">
							<a href="#" class="dcjq-parent"> <i class="fa fa-table"></i> <span>Videos </span> <span class="arrow"></span> <span class="dcjq-icon"></span></a>
							<ul class="down_menu" >
								<li>
									<a href="HindiVideo.php">Hindi</a>
								</li>
								<li>
									<a href="EnglishVideo.php">English</a>
								</li>
								<li>
									<a href="MatematicsVideo.php">Mathematics</a>
								</li>
								<li>
									<a href="ScienceVideo.php">Science</a>
								</li>
								<li>
									<a href="SocialScienceVideo.php">Social Science</a>
								</li>
								<li>
									<a href="SanskritVideo.php">Sanskrit</a>
								</li>
							</ul>
						</li>
						<!-- <li class="menu_sub dcjq-parent-li">
							<a href="#" class="dcjq-parent"> <i class="fa fa-table"></i> <span>Reports </span> <span class="arrow"></span> <span class="dcjq-icon"></span></a>
							<ul class="down_menu" style="display: none;">
								<li>
									<a href="#">Category Wise Deals</a>
								</li>
								<li>
									<a href="#">Location Wise Deals</a>
								</li>
							</ul>
						</li> -->
						
						<li class="menu_sub">
							<a href="Upload.php"> <i class="fa fa-table"></i> <span> Upload </span>  </a>
							
						</li>
						<li class="menu_sub">
							<a href="Tests.php"> <i class="fa fa-table"></i> <span> Tests </span>  </a>
							
						</li>
						<li class="menu_sub">

						<a href="#"><i class="fa fa-table"></i> <span>Logout</span></a>
					</li>
					</ul>
				</div>
				