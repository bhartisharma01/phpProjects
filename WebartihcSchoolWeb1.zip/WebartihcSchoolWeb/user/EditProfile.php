<?php include 'dashboard-header.php';?>

			<!-- Content_right -->
			<div class="container_full">

				<?php include 'left-sidebar.php'; ?>

				<div class="content_wrapper">
					<div class="container-fluid">
						<!-- breadcrumb -->
						<div class="page-heading">
							<div class="row d-flex align-items-center">
								<div class="col-md-6">
									<div class="page-breadcrumb">
										<!-- <h1>Add Vendor</h1> -->
									</div>
								</div>
								<div class="col-md-6 justify-content-md-end d-md-flex">
									<div class="breadcrumb_nav">
										<ol class="breadcrumb">
											<li>
												<i class="fa fa-home"></i>
												<a class="parent-item" href="index.php">Home</a>
												<i class="fa fa-angle-right"></i>
											</li>
											<li class="active">
												Edit Profile
											</li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<!-- breadcrumb_End -->
</div>

<div class="container-fluid">
						<!-- state start-->
	<div class="row">
		<div class=" col-xl-12">
            <div class="topsection">
              <ul class="square" style="
">
                <li><a>My Learning Dashboard</a></li>
                <li><a href="Profile.php">Dashboard</a></li>
                <li class="user-name" style="margin-top: 10px">Edit Profile</li>
              </ul>
            </div>
			<div class="card card-shadow mb-4">
				
				<div class="card-header">
					<div class="card-title">
						<h3>STUDENT INFORMATION</h3>
					</div>
				</div>
				<div class="card-body profile-table">
                    <span class="text-danger"></span>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="editform">
                       <form method="post" action="" enctype="multipart/form-data"></form>
            
            <tbody><tr>
              <td>Profile</td>
              <td>:</td>
              <td><input type="file" name="profile_pic" class="form-control">
                
              </td>
            </tr>
            <tr>
              <td>Student Id</td>
              <td>:</td>
              <td>
                <input type="text" name="studentId" class="form-control">
              </td>
            </tr>
            <tr>
              <td>Roll No.</td>
              <td>:</td>
              <td>
                <input type="text" name="rollNumber" class="form-control" >
                
              </td>
            </tr>
            <tr>
              <td>Name</td>
              <td>:</td>
              <td><input type="text" name="yourName" class="form-control"></td>
            </tr>
            <tr>
              <td>School's Name </td>
              <td>:</td>
              <td><input type="text" name="schoolName" class="form-control"></td>
            </tr>
            <tr>
              <td>Class</td>
              <td>:</td>
              <td><input type="text" name="Class" class="form-control"></td>
            </tr>
            <tr>
              <td>Section</td>
              <td>:</td>
              <td><input type="text" name="Section" class="form-control"></td>
            </tr>
            <tr>
              <td>Medium</td>
              <td>:</td>
              <td><input type="text" name="Medium" class="form-control"></td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>:</td>
              <td><input type="text" name="Gender" class="form-control"></td>
            </tr>
            <tr>
              <td>Date of Birth</td>
              <td>:</td>
              <td><input type="text" name="DateofBirth" class="form-control"></td>
            </tr>
            <tr>
                    <td>Address</td>
                    <td>:</td>
                    <td><input type="text" name="Address" class="form-control"></td>
            </tr>
            <tr>
                    <td>Password</td>
                    <td>:</td>
                    <td><input type="text" name="Password" class="form-control"></td>
            </tr>

          </tbody></table>
				  <br>
				  <div class="edit-profile-box">
					  <a href="" class="bg_red update-btn">
						 Update </a> 
				  </div>				
				</div>
			</div>
		</div>
	</div>
						<!-- state end-->
</div>

	</div>
</div>
			<?php include 'dashboard-footer.php';?>
		

