<?php include 'dashboard-header.php';?>

			<!-- Content_right -->
			<div class="container_full">

				<?php include 'left-sidebar.php'; ?>

				<div class="content_wrapper">
					<div class="container-fluid">
						<!-- breadcrumb -->
						<div class="page-heading">
							<div class="row d-flex align-items-center">
								<div class="col-md-6">
									<div class="page-breadcrumb">
										<!-- <h1>Add Vendor</h1> -->
									</div>
								</div>
								<div class="col-md-6 justify-content-md-end d-md-flex">
									<div class="breadcrumb_nav">
										<ol class="breadcrumb">
											<li>
												<i class="fa fa-home"></i>
												<a class="parent-item" href="index.php">Home</a>
												<i class="fa fa-angle-right"></i>
											</li>
											<li class="active">
												My Profile
											</li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<!-- breadcrumb_End -->
</div>

<div class="container-fluid">
						<!-- state start-->
	<div class="row">
		<div class=" col-xl-12">
			<div class="topsection">
              <ul class="square" style="
">
                <li><a>My Learning Dashboard</a></li>
                <li><a href="Profile.php">My Profile</a></li>
                <li class="user-name" style="margin-top: 10px">Harshit Sharma</li>
              </ul>
            </div>
			<div class="card card-shadow mb-4">
				
				<div class="card-header">
					<div class="card-title">
						<h3>Dashboard</h3>
					</div>
				</div>
				<div class="card-body profile-table">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    
                    <tbody><tr>
                      <td>Registration Date </td>
                      <td>:</td>
                      <td>2020-09-14</td>
                    </tr>
                    <tr>
                      <td>Student Id </td>
                      <td>:</td>
                      <td>20190202324</td>
                    </tr>
                    <tr>
                      <td>Roll No</td>
                      <td>:</td>
                      <td>7237</td>
                    </tr>

                    <tr>
                      <td>Name</td>
                      <td>:</td>
                      <td>Harshit Sharma</td>
                    </tr>
                    <tr>
                      <td>School's Name</td>
                      <td>:</td>
                      <td>Govt. Sarvodaya co-ed vidyalaya sec-4 Rohini Delhi-110085</td>
                    </tr>
                    <tr>
                      <td>Class </td>
                      <td>:</td>
                      <td>7</td>
                    </tr>
                    <tr>
                      <td>Section</td>
                      <td>:</td>
                      <td>B</td>
                    </tr>
                    <tr>
                      <td>Medium</td>
                      <td>:</td>
                      <td>English</td>
                    </tr>
                    <tr>
                      <td>Gender</td>
                      <td>:</td>
                      <td>Male</td>
                    </tr>
                    <tr>
                      <td>Date of Birth</td>
                      <td>:</td>
                      <td>26-09-2008</td>
                    </tr>
                    <tr>
                      <td>Address</td>
                      <td>:</td>
                      <td>Budh Vihar Phase-1 Delhi - 110086</td>
                    </tr>
                    <tr>
                      <td>Status</td>
                      <td>:</td>
                      <td>Active</td>
                    </tr>


				  </tbody></table>
				  <br>
				  <div class="edit-profile-box">
					  <a href="EditProfile.php?Student_id=2" class="bg_red editbtn">
						<i class="fa fa-pencil"></i> Edit Profile</a> 
				  </div>				
				</div>
			</div>
		</div>
	</div>
						<!-- state end-->
</div>

	</div>
</div>
			<?php include 'dashboard-footer.php';?>
		

