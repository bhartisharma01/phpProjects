<?php 
include 'header.php';
?>

<body style="background: #fff url(images/admin-login-background.png);background-attachment: fixed;background-repeat: repeat;" data-gr-c-s-loaded="true">
 	<div class="container">
 		<div class="row">
 			<div class="col-md-3"></div>

 			<div class="col-md-6 text-center">
 				<div class="admin-login-form">
 					<div class="admin-header-info">
 						<img src="images/logo.png" alt="" class="admin-logo">
 						<h3 class="admin-text">
 							Please Enter Your Information
 						</h3>
 					</div>

 					<form action="" method="POST">
						<div class="form-group">
							<input type="email" class="form-control" id="emailid" aria-describedby="emailHelp" placeholder="Username">
						</div>
						<div class="form-group">
							<input type="password" class="form-control" id="password" placeholder="Password">
						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-primary admin-login-btn form-control">
						</div>
					</form>
					<div class="admin-login-copyrights">Designed &amp; Developed By : <a href="#" target="_blank">Webartihc Technologies</a></div>
 					</div>
 				</div>
				 <div class="col-md-3"></div>
			</div>
 		</div>
<?php
include 'footer.php';
?>