
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Webartihc  </title>
		<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
		<!-- google font -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/ionicons.css" rel="stylesheet" type="text/css">
		<link href="css/simple-line-icons.css" rel="stylesheet" type="text/css">
<!--Morris Chart -->
		<link rel="stylesheet" href="css/morris.css">
		<link href="css/jquery.mCustomScrollbar.css" rel="stylesheet">
		<link href="css/weather-icons.min.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive.css" rel="stylesheet">
	</head>