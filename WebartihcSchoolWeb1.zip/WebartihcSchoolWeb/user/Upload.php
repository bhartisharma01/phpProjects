<?php include 'dashboard-header.php';?>

			<!-- Content_right -->
			<div class="container_full">

				<?php include 'left-sidebar.php'; ?>

				<div class="content_wrapper">
					<div class="container-fluid">
						<!-- breadcrumb -->
						<div class="page-heading">
							<div class="row d-flex align-items-center">
								<div class="col-md-6">
									<div class="page-breadcrumb">
										<!-- <h1>Add Vendor</h1> -->
									</div>
								</div>
								<div class="col-md-6 justify-content-md-end d-md-flex">
									<div class="breadcrumb_nav">
										<ol class="breadcrumb">
											<li>
												<i class="fa fa-home"></i>
												<a class="parent-item" href="index.php">Home</a>
												<i class="fa fa-angle-right"></i>
											</li>
											<li class="active">
												My Profile
											</li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<!-- breadcrumb_End -->
</div>

<div class="container-fluid">
						<!-- state start-->
	<div class="row">
		<div class=" col-xl-12">
			<div class="topsection">
              <ul class="square" style="
">
                <li><a>My Learning Dashboard</a></li>
                <li><a href="Profile.php">My Profile</a></li>
                <li class="user-name" style="margin-top: 10px">Harshit Sharma</li>
              </ul>
            </div>
			<div class="card card-shadow mb-4">
				
				<div class="card-header">
					<div class="card-title">
						<h3>Dashboard</h3>
					</div>
				</div>
				<div class="card-body profile-table">
                                <form method="post" action="" enctype="multipart/form-data">

        <div class="row mt-3">
            <div class="col-md-4">
                <div class="form-group">
                    <input type="text" class="form-control" id="schoolName"   name="schoolName" autocomplete="off" value="Govt. Sarvodaya co-ed vidayala sec-4" readonly>

                </div>
</div>
           
            <div class="col-md-4">
                <div class="form-group">
							        <select name="Class" id="class" class="form-control">
							        	<option value="">Select Class</option>
							        	<option value="">6</option>
							        	<option value="">7</option>
							        	<option value="">8</option>
							        	<option value="">9</option>
							        	<option value="">10</option>
							        </select>
			    </div>
            </div>
            <div class="col-md-4">
                                <div class="form-group">
							        <select name="Section" id="section" class="form-control">
							        	<option value="">Select Section</option>
							        	<option value="">A</option>
							        	<option value="">B</option>
							        	<option value="">C</option>
							        	<option value="">D</option>
							        	<option value="">E</option>
							        </select>
						        </div>
                            </div>
        

        </div>
        <div class="row">
            <div class="col-md-4">
                                <div class="form-group">
							        <select name="Subject" id="subject" class="form-control">
							        	<option value="">Select Subject</option>
							        	<option value="">Hindi</option>
							        	<option value="">English</option>
							        	<option value="">Mathematics</option>
							        	<option value="">Science</option>
                                        <option value="">Social Science</option>
                                        <option value="">Sanskrit</option>
							        </select>
						        </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <input type="text" name="upload-title" value="" class="form-control" placeholder="Title">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
<input type="file" name="subjectWork" value="" class="form-control">                                </div>
                            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="edit-profile-box">
					  <a href="" class="bg_red update-btn">
						 Upload </a> 
				  </div>
            </div>
        </div>
            </form>
				 				
				</div>
			</div>
		</div>
	</div>
						<!-- state end-->
</div>

	</div>
</div>
			<?php include 'dashboard-footer.php';?>
		

