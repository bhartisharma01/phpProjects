<?php include 'dashboard-header.php';?>

			<!-- Content_right -->
			<div class="container_full">

				<?php include 'left-sidebar.php'; ?>

				<div class="content_wrapper">
					<div class="container-fluid">
						<!-- breadcrumb -->
						<div class="page-heading">
							<div class="row d-flex align-items-center">
								<div class="col-md-6">
									<div class="page-breadcrumb">
										<!-- <h1>Add Vendor</h1> -->
									</div>
								</div>
								<div class="col-md-6 justify-content-md-end d-md-flex">
									<div class="breadcrumb_nav">
										<ol class="breadcrumb">
											<li>
												<i class="fa fa-home"></i>
												<a class="parent-item" href="index.php">Home</a>
												<i class="fa fa-angle-right"></i>
											</li>
											<li class="active">
												Announcements
											</li>
										</ol>
									</div>
								</div>
							</div>
						</div>
						<!-- breadcrumb_End -->
</div>

<div class="container-fluid">
						<!-- state start-->
	<div class="row">
		<div class=" col-xl-12">
            <div class="topsection">
              <ul class="square" style="
">
                <li><a>My Learning Dashboard</a></li>
                <li><a href="Announcements.php">Announcements</a></li>
              </ul>
            </div>
			<div class="card card-shadow mb-4">
				
				<div class="card-header">
					<div class="card-title">
						<h3>Announcements</h3>
					</div>
				</div>
				<div class="card-body profile-table">
				
				  <table width="100%" border="0" cellpadding="0" cellspacing="0" class="announce">
  <tbody><tr>
    <td>
		<div class="announe_date">Date : 14-09-2020</div>
		Stay Home, Stay Safe! Keep social distancing.
	</td>
  </tr>
  
</tbody></table>				
				</div>
			</div>
		</div>
	</div>
						<!-- state end-->
</div>

	</div>
</div>
			<?php include 'dashboard-footer.php';?>
		

